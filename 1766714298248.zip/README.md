# Sign Up Form Handler

Create and submit a simple form (signup form) in Spring MVC application using Spring MVC 5+, Maven build tool, JSP

![Sign Up](https://www.linkpicture.com/q/signup-form.png)

![Sign Up](https://www.linkpicture.com/q/Screenshot-2022-03-02-151951.png)


## Technologies Used

### Front-End
- JSP
- CSS

### Back-End
- Spring
- Java




